package com.quiz.byomkar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;

public class ninequestion extends AppCompatActivity {

    CheckBox check1,check2,check3,check4;
    public static int count=eigthquestion.count;
    boolean flag;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ninequestion);
        check1=findViewById(R.id.check1);
        check2=findViewById(R.id.check2);
        check3=findViewById(R.id.check3);
        check4=findViewById(R.id.check4);
    }
    public void check(View view) {
        switch (view.getId())
        {
            case R.id.check1 : check2.setChecked(false);
                check3.setChecked(false);
                check4.setChecked(false); flag=false;break;
            case R.id.check2 : check1.setChecked(false);
                check3.setChecked(false);
                check4.setChecked(false);
                flag=false; break;
            case R.id.check3 : check2.setChecked(false);
                check1.setChecked(false);
                check4.setChecked(false); flag=true;break;
            case R.id.check4 : check2.setChecked(false);
                check3.setChecked(false);
                check1.setChecked(false); flag=false;break;

            default: flag=false; break;

        }

    }
    public void onBackPressed(){
        Toast.makeText(this,"Please complete all the question", Toast.LENGTH_SHORT).show();
    }

    public void next(View view) {
        if (flag)
            count++;
        startActivity(new Intent(this,tenthquestion.class));
    }

}
