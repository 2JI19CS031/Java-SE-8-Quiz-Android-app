package com.quiz.byomkar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {

    EditText email,password;
    Button login;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        email=findViewById(R.id.email);
        password=findViewById(R.id.password);
        login=findViewById(R.id.login);
        mAuth = FirebaseAuth.getInstance();

        login.setOnClickListener((View)->{
            String email1=email.getText().toString();
            String password1=password.getText().toString();
            mAuth
                    .signInWithEmailAndPassword(email1,password1)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()){

                            Toast.makeText(Login.this,"Successfully stored",Toast.LENGTH_LONG).show();
                            startActivity(new Intent(Login.this,MainActivity.class));
                        }
                        else
                        {

                            Toast.makeText(Login.this,"Sorry You have not registered",Toast.LENGTH_LONG).show();
                            startActivity(new Intent(Login.this,Register.class));
                        }


                    });

        });
    }
}