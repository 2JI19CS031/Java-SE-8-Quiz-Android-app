package com.quiz.byomkar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class Register extends AppCompatActivity {

    private FirebaseAuth mAuth;
    Button b1;
    EditText email,passwd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();
        email=findViewById(R.id.email);
        passwd=findViewById(R.id.Password);
        b1=findViewById(R.id.submit);
        b1.setOnClickListener((View)->{
            String email1=email.getText().toString();
            String password=passwd.getText().toString();
            mAuth
                    .createUserWithEmailAndPassword(email1,password)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()){

                            Toast.makeText(Register.this,"Successfully stored",Toast.LENGTH_LONG).show();
                            startActivity(new Intent(Register.this,MainActivity.class));
                        }
                        else
                        {

                            Toast.makeText(Register.this,"UnSuccessful",Toast.LENGTH_LONG).show();
                        }


                    });

        });
    }
}